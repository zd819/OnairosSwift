(function () {
  function install() {
    const device = document.getElementById('device');
    const screen = document.getElementById('screen');
    const frame = document.getElementById('frame');
    const stage = device && device.closest('.stage');
    if (!stage || !screen || !frame || !document.body.classList.contains('browserLike')) return;
    let ratio = device.clientWidth / Math.max(1, device.clientHeight);
    const style = document.createElement('style');
    style.textContent = `
      body.browserLike .stage { display:block!important; overflow-y:auto!important; overflow-x:hidden!important; overscroll-behavior:contain; }
      body.browserLike .device { width:100%!important; height:var(--onairos-stream-height)!important; flex:none!important; margin:0!important; }
      body.browserLike .screen { width:100%!important; height:100%!important; }
      body.browserLike .screen canvas { width:100%!important; height:100%!important; }
    `;
    document.head.appendChild(style);
    // Freeze the remote aspect ratio, never the keyboard-reduced container height.
    let focusY = null;
    let previousHeight = stage.clientHeight;
    let keyboardOpen = false;
    let gesture = null;
    let replaying = false;
    function layout() {
      if (frame.width > 0 && frame.height > frame.width) ratio = frame.width / frame.height;
      const height = Math.round(stage.clientWidth / ratio);
      device.style.setProperty('--onairos-stream-height', height + 'px');
      const available = stage.clientHeight;
      if (available < previousHeight - 60) keyboardOpen = true;
      if (available > previousHeight + 60) keyboardOpen = false;
      previousHeight = available;
      if (keyboardOpen && focusY !== null) {
        const target = focusY * height;
        const top = stage.scrollTop + 36;
        const bottom = stage.scrollTop + available - 72;
        if (target < top || target > bottom) stage.scrollTop = Math.max(0, target - available * 0.5);
      }
    }
    function isStream(event) {
      return event.target === screen || event.target === frame;
    }
    function replay(type, point) {
      replaying = true;
      try {
        screen.dispatchEvent(new PointerEvent(type, {
          bubbles: true, cancelable: true, pointerId: point.id,
          pointerType: point.kind, clientX: point.x, clientY: point.y,
          button: 0, buttons: type === 'pointerdown' ? 1 : 0, isPrimary: true
        }));
      } finally { replaying = false; }
    }
    // Consume local vertical travel first. At the edges, continue scrolling the
    // remote page through its existing wheel handler (in remote pixel units).
    screen.addEventListener('pointerdown', function (event) {
      if (replaying || !isStream(event) || !event.isPrimary) return;
      event.preventDefault(); event.stopImmediatePropagation();
      gesture = {id: event.pointerId, kind: event.pointerType, x: event.clientX, y: event.clientY, lastY: event.clientY, moved: false};
      try { screen.setPointerCapture(event.pointerId); } catch (_) {}
    }, true);
    screen.addEventListener('pointermove', function (event) {
      if (replaying || !gesture || event.pointerId !== gesture.id) return;
      event.preventDefault(); event.stopImmediatePropagation();
      if (Math.abs(event.clientY - gesture.y) > 6 || Math.abs(event.clientX - gesture.x) > 6) gesture.moved = true;
      if (!gesture.moved) return;
      const delta = gesture.lastY - event.clientY; gesture.lastY = event.clientY;
      const before = stage.scrollTop; stage.scrollTop += delta;
      const remaining = delta - (stage.scrollTop - before);
      if (Math.abs(remaining) > 1) {
        // Match the viewer's existing wheel contract; frame.width is render
        // resolution, not remote CSS pixels, and must not multiply scroll speed.
        screen.dispatchEvent(new WheelEvent('wheel', {bubbles: true, cancelable: true, deltaY: remaining}));
      }
    }, true);
    function end(event) {
      if (replaying || !gesture || event.pointerId !== gesture.id) return;
      event.preventDefault(); event.stopImmediatePropagation();
      const point = gesture; gesture = null;
      try { screen.releasePointerCapture(event.pointerId); } catch (_) {}
      if (event.type === 'pointercancel' || point.moved) return;
      const rect = frame.getBoundingClientRect();
      focusY = (point.y - rect.top) / Math.max(1, rect.height);
      // Existing backend mapping uses getBoundingClientRect, including scroll
      // offset. Replay taps only; never duplicate drags into remote clicks.
      replay('pointerdown', point); replay('pointerup', point);
    }
    screen.addEventListener('pointerup', end, true);
    screen.addEventListener('pointercancel', end, true);
    window.addEventListener('resize', layout);
    if (window.visualViewport) window.visualViewport.addEventListener('resize', layout);
    new ResizeObserver(layout).observe(stage);
    new MutationObserver(layout).observe(frame, {attributes: true, attributeFilter: ['width', 'height']});
    layout();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, {once:true});
  else install();
})();
