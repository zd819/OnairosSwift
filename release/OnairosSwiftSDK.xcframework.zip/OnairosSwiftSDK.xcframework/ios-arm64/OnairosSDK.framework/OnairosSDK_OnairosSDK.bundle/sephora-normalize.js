function normalizeSephoraImport(data) {
  const mobileMetadata = {
    platform: "ios",
    source: "webview-api",
    isOfflineSync: false,
    extractedAt: new Date().toISOString(),
    tokenExpiry: data.tokenExpiry
  };
  const parseCurrencyNumber = value => {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string') {
      const cleaned = value.replace(/[^0-9.-]/g, '');
      const parsed = Number(cleaned);
      return Number.isFinite(parsed) ? parsed : 0;
    }
    return 0;
  };
  const normalizeOrderDate = value => {
    if (!value) return undefined;
    if (typeof value === 'string') return value;
    if (typeof value === 'number') return new Date(value).toISOString();
    return undefined;
  };

  // Use purchases or fall back to orders for backward compatibility
  const purchases = data.purchases || data.orders || [];
  const normalizedPurchases = purchases.map(order => {
    const normalizedOrderDate = normalizeOrderDate(order.orderDate || order.date || order.purchaseDate);
    const normalizedItems = (order.items || []).map(item => ({
      skuId: typeof item.skuId === 'string' ? item.skuId : String(item.skuId || ''),
      productId: item.productId,
      name: item.name,
      brand: item.brand,
      price: parseCurrencyNumber(item.price),
      quantity: item.quantity
    })).filter(item => !!item.skuId && !!item.name);
    const explicitTotal = parseCurrencyNumber(order.total || order.orderTotal);
    const computedTotal = normalizedItems.reduce((sum, item) => sum + item.price * (Number(item.quantity) > 0 ? Number(item.quantity) : 1), 0);
    return {
      orderId: order.orderId,
      orderDate: normalizedOrderDate,
      // Keep legacy aliases for backend compatibility.
      date: normalizedOrderDate,
      purchaseDate: normalizedOrderDate,
      total: explicitTotal > 0 ? explicitTotal : computedTotal,
      channel: order.channel || (order.isOnline ? 'online' : undefined),
      status: order.status || 'completed',
      items: normalizedItems
    };
  }).filter(order => !!order.orderId && !!order.orderDate && order.items.length > 0);
  const flattenedPurchasedItems = normalizedPurchases.reduce((acc, order) => {
    const mappedItems = (order.items || []).map(item => ({
      orderId: order.orderId,
      date: order.orderDate,
      purchaseDate: order.orderDate,
      isOnline: order.channel ? order.channel.toLowerCase() !== 'store' : true,
      quantity: item.quantity || 1,
      sku: {
        skuId: item.skuId,
        productId: item.productId,
        displayName: item.name,
        productName: item.name,
        brandName: item.brand,
        listPrice: item.price
      }
    }));
    return acc.concat(mappedItems);
  }, []);
  const normalizedBasketSubtotal = parseCurrencyNumber(data.basket?.subtotal || data.basket?.total || 0);

  // Build request body - normalized format for backend
  const requestBody = {
    // Keep the canonical SDK platform identifier for backend routing.
    platform: 'mobile-sephora',
    platformAlias: 'sephora',
    connectorPlatform: 'mobile-sephora',
    dataType: 'ecommerce',
    data: {
      basket: {
        items: (data.basket?.items || []).map(item => ({
          skuId: item.skuId || item.id,
          productId: item.productId,
          name: item.name,
          brand: item.brand,
          price: parseCurrencyNumber(item.price),
          quantity: item.quantity,
          size: item.size,
          imageUrl: item.imageUrl
        })),
        subtotal: normalizedBasketSubtotal,
        // Legacy alias some backend paths still look for.
        total: normalizedBasketSubtotal,
        biPoints: data.basket?.biPoints || 0,
        itemCount: data.basket?.items?.length || 0
      },
      // Legacy alias: some backend counters look for bag instead of basket.
      bag: {
        items: (data.basket?.items || []).map(item => ({
          skuId: item.skuId || item.id,
          productId: item.productId,
          name: item.name,
          brand: item.brand,
          price: parseCurrencyNumber(item.price),
          quantity: item.quantity
        })),
        total: normalizedBasketSubtotal,
        itemCount: data.basket?.items?.length || 0
      },
      loves: (data.loves || []).map(love => ({
        skuId: love.skuId || love.id,
        productId: love.productId,
        name: love.name,
        brand: love.brand,
        category: love.category,
        price: parseCurrencyNumber(love.price),
        salePrice: parseCurrencyNumber(love.salePrice),
        rating: love.rating,
        reviewCount: love.reviewCount,
        isInStock: love.isInStock,
        isOnSale: love.isOnSale,
        imageUrl: love.imageUrl,
        addedAt: love.addedAt
      })),
      // Legacy aliases seen in older backend pipelines.
      lovedProducts: (data.loves || []).map(love => ({
        skuId: love.skuId || love.id,
        productId: love.productId,
        name: love.name,
        brand: love.brand,
        type: 'love'
      })),
      purchases: normalizedPurchases,
      // Legacy alias (older backend parser uses `orders` + `date`).
      orders: normalizedPurchases,
      purchaseHistory: normalizedPurchases,
      // Legacy alias matching Sephora API shape consumed by backend parsers.
      purchasedItems: flattenedPurchasedItems,
      purchasedItemsCount: flattenedPurchasedItems.length,
      profile: data.profile ? {
        profileId: data.profile.profileId,
        firstName: data.profile.firstName,
        vibStatus: data.profile.vibStatus,
        beautyInsider: data.profile.beautyInsider,
        preferences: data.profile.preferences,
        preferredStore: data.profile.preferredStore
      } : null,
      sephoraProfileId: data.profileId || data.profile?.profileId
    },
    summary: {
      basketItemCount: data.basket?.items?.length || 0,
      basketSubtotal: normalizedBasketSubtotal,
      basketTotal: normalizedBasketSubtotal,
      biPoints: data.profile?.beautyInsider?.points || data.basket?.biPoints || 0,
      lovedProductCount: data.loves?.length || 0,
      purchaseCount: normalizedPurchases.length,
      orderCount: normalizedPurchases.length,
      purchasesCount: normalizedPurchases.length,
      purchasedItemsCount: flattenedPurchasedItems.length,
      totalPurchasedItems: normalizedPurchases.reduce((sum, order) => sum + (order.items?.length || 0), 0),
      vibStatus: data.profile?.vibStatus || 'unknown'
    },
    mobileMetadata: mobileMetadata
  };
  return requestBody;
}