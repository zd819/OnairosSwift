
(function(){
  if(location.origin !== "https://chatgpt.com" || window.top !== window.self) return;
  if(window.__onairosNativeImport) window.__onairosNativeImport.abort();
  var controller = new AbortController(); window.__onairosNativeImport = controller;
  var token = null, timedOut = false,orgId=null;
  var importRequestId="__REQUEST__";
  var platform="chatgpt",includeFiles=false;
  var timer = setTimeout(function(){timedOut=true;controller.abort();}, 25000);
  var requestId=importRequestId;
  function send(value){if(JSON.stringify(value).length>3900000)throw new Error('unavailable');if(window.__onairosNativeImport===controller && (!controller.signal.aborted || timedOut)) window.webkit.messageHandlers.onairosImport.postMessage(JSON.stringify(Object.assign({channel:'onairos-native-import',requestId:"__REQUEST__"},value)));}
  var cooldownUntil=0;
  function wait(ms){return new Promise(function(resolve,reject){
    var onAbort=function(){clearTimeout(timeout);reject(new Error('cancelled'));};
    var timeout=setTimeout(function(){controller.signal.removeEventListener('abort',onAbort);resolve();},ms);
    controller.signal.addEventListener('abort',onAbort,{once:true});
    if(controller.signal.aborted)onAbort();
  });}
  async function read(path, authenticated){
    for(var attempt=0;attempt<2;attempt++){
      if(controller.signal.aborted)throw new Error('cancelled');
      if(cooldownUntil>Date.now())await wait(cooldownUntil-Date.now());
      var local=new AbortController();
      var abort=function(){local.abort();};controller.signal.addEventListener('abort',abort,{once:true});
      var requestTimer=setTimeout(function(){local.abort();},20000);
      try{
        var response=await fetch(path,{credentials:'include',redirect:'error',signal:local.signal,headers:authenticated?{Accept:'application/json',Authorization:'Bearer '+token}:{Accept:'application/json'}});
        if(response.status===429 && attempt===0){
          var retry=response.headers.get('Retry-After'), seconds=Number(retry);
          var delay=retry && Number.isFinite(seconds)?seconds*1000:Math.max(0,Date.parse(retry)-Date.now())||2000;
          if(delay>30000)throw new Error('rate_limited');
          cooldownUntil=Math.max(cooldownUntil,Date.now()+Math.max(1000,delay));
          send({type:'cooldown',retryAt:cooldownUntil});continue;
        }
        if(!response.ok)throw new Error(response.status===401 || response.status===403?'sign_in':response.status===429?'rate_limited':response.status===404?'conversation_unavailable':'provider_error');
        try{return await response.json();}catch(parseError){if(local.signal.aborted)throw parseError;throw new Error('invalid_response');}
      }catch(error){if(local.signal.aborted && !controller.signal.aborted)throw new Error('timeout');if(error.name==='TypeError')throw new Error('network');throw error;}
      finally{clearTimeout(requestTimer);controller.signal.removeEventListener('abort',abort);}
    }
  }
  var metadataKeys=["model","model_slug","modelSlug","default_model_slug","defaultModelSlug","resolved_model_slug","resolvedModelSlug","actual_model_slug","actualModelSlug","current_model_slug","currentModelSlug","sources","safe_urls","safeUrls","citations","content_references","contentReferences","search_result_groups","searchResultGroups","tools","tool_calls","toolCalls","search_queries","searchQueries","search_query","query","q","queries","query_type","searchQuery","type","title","name","label","url","uri","link","site_name","siteName","domain","alt","matched_text","text","integration_name","integrationName","items","entries","refs","reference","references","source","results","result","content","contentBlocks","display_content","displayContent","metadata","input","id","status","recipient","channel","content_type","contentType","current_node","currentNode","conversation_template_id","conversationTemplateId","created_at","createdAt","updated_at","updatedAt","create_time","update_time","summary"];
  function cleanMetadata(value){
    var budget=32000,nodes=0;
    function visit(v,depth,key){
      if(++nodes>1500 || depth>7 || budget<=0)return;
      if(typeof v==='string'){
        var text=v.slice(0,Math.min(4096,budget));
        if(['url','uri','link','safe_urls','safeUrls'].includes(key) && (!/^https?:\/\/[^\s/@]+(?:[/:?#]|$)/i.test(text) || /[?&](?:[^=&]*(?:token|signature|credential|secret|key)|sig)=/i.test(text)))return;
        budget-=text.length;return text;
      }
      if(v===null || typeof v==='boolean' || typeof v==='number'&&Number.isFinite(v))return v;
      if(Array.isArray(v))return v.slice(0,50).map(function(item){return visit(item,depth+1,key);}).filter(function(item){return item!==undefined;});
      if(!v || typeof v!=='object' || /^(thinking|reasoning|analysis)$/.test(v.type||''))return;
      var result={};Object.keys(v).forEach(function(k){if(metadataKeys.includes(k)){var item=visit(v[k],depth+1,k);if(item!==undefined)result[k]=item;}});return result;
    }
    return visit(value,0,'')||{};
  }
  function extraMessageFields(m,parent){
    var meta=Object.assign({},m.metadata||{});
    ['model','model_slug','sources','citations','content_references','tools','tool_calls','search_queries'].forEach(function(key){if(m[key]!==undefined)meta[key]=m[key];});
    if(m.author&&m.author.metadata)Object.assign(meta,m.author.metadata);
    if(Array.isArray(m.content))meta.contentBlocks=m.content.map(function(block){
      if(block.type==='text')return {citations:block.citations};return block;
    });
    function collectBlocks(blocks,depth){
      if(!Array.isArray(blocks)||depth>4)return;
      blocks.slice(0,50).forEach(function(block){
        if(!block || /^(thinking|reasoning|analysis)$/.test(block.type||''))return;
        if(Array.isArray(block.citations))meta.citations=(Array.isArray(meta.citations)?meta.citations:[]).concat(block.citations).slice(0,50);
        if(block.type==='tool_use' || block.type==='tool_result')meta.tools=(Array.isArray(meta.tools)?meta.tools:[]).concat([{name:block.name||block.integration_name||block.type,integrationName:block.integration_name}]).slice(0,50);
        if(block.type==='knowledge' && block.url)meta.sources=(Array.isArray(meta.sources)?meta.sources:[]).concat([{url:block.url,title:block.title}]).slice(0,50);
        if(block.input && (block.input.query || block.input.search_query))meta.search_queries=(Array.isArray(meta.search_queries)?meta.search_queries:[]).concat([{query:block.input.query||block.input.search_query,type:block.name||block.type}]).slice(0,50);
        collectBlocks(block.content,depth+1);
      });
    }
    collectBlocks(m.content,0);
    return {metadata:cleanMetadata(meta),prevMessageId:parent||m.parent_message_uuid||m.parent_uuid||undefined,
      modelSlug:meta.resolved_model_slug||meta.model_slug||m.model||undefined,
      updatedAt:m.update_time||m.updated_at||undefined,contentType:m.content?.content_type,
      channel:m.channel,recipient:m.recipient,status:m.status};
  }

  
  (async function(){try{
    if(platform==='claude'){
      var orgPayload=await read('/api/organizations',false),orgs=Array.isArray(orgPayload)?orgPayload:orgPayload.organizations||[];
      var activeOrg=(document.cookie.match(/(?:^|; )lastActiveOrg=([^;]+)/)||[])[1];
      var org=orgs.find(function(o){return (o.uuid||o.id)===activeOrg;})||orgs[0];orgId=org&&(org.uuid||org.id);orgPayload=null;orgs=null;
      if(!orgId)throw new Error('sign_in');
    }else{
      var session=await read('/api/auth/session',false);token=session.accessToken;session=null;
      if(typeof token!=='string' || !token) throw new Error('sign_in');
    }
    var selected=null;
    if(selected===null){
      var items=[],seen={};
      var pageSize=platform==='claude'?30:50;
      for(var offset=0;offset<100;offset+=pageSize){
        var list=await read(platform==='claude'?'/api/organizations/'+encodeURIComponent(orgId)+'/chat_conversations?offset='+offset+'&limit='+pageSize:'/backend-api/conversations?offset='+offset+'&limit='+pageSize+'&order=updated',platform==='chatgpt');
        if(platform==='claude')list={items:(Array.isArray(list)?list:list.chat_conversations||list.conversations||list.items||[]).map(function(c){return {id:c.uuid||c.id,title:c.name||c.title};})};
        if(!Array.isArray(list.items)) throw new Error('unavailable');
        list.items.forEach(function(item){if(typeof item.id==='string' && /^[a-zA-Z0-9-]{1,128}$/.test(item.id) && !seen[item.id]){seen[item.id]=true;items.push({id:item.id,title:String(item.title||'Untitled conversation').slice(0,500)});}});
        if(list.items.length<pageSize || (typeof list.total==='number' && offset+pageSize>=list.total))break;
      }
      send({type:'titles',items:items.slice(0,100)});return;
    }
    var next=0,completed=0;
    async function worker(){while(next<selected.length && !controller.signal.aborted){
      var item=selected[next++];
      send({type:'item',id:item.id,status:'importing'});
      var detail=await read(platform==='claude'?'/api/organizations/'+encodeURIComponent(orgId)+'/chat_conversations/'+encodeURIComponent(item.id)+'?tree=true&rendering_mode=messages&render_all_tools=true':'/backend-api/conversation/'+encodeURIComponent(item.id),platform==='chatgpt');
      var sourceMessages=[],parents={};
      if(platform==='chatgpt'){
        if(!detail.mapping || !detail.current_node)throw new Error('invalid_response');
        var nodes=[],cursor=detail.current_node,visited={};
        while(cursor && detail.mapping[cursor] && !visited[cursor]){visited[cursor]=true;var node=detail.mapping[cursor];nodes.push(node);if(node.message)parents[node.message.id]=node.parent;cursor=node.parent;}
        sourceMessages=nodes.reverse().map(function(node){return node.message;}).filter(Boolean);
      }else{
        var root=detail.conversation||detail.data||detail;
        sourceMessages=root.chat_messages||root.messages||[];
        if(!Array.isArray(sourceMessages))throw new Error('unavailable');
        if(root.current_leaf_message_uuid){
          var byId={},branch=[],seenNodes={};sourceMessages.forEach(function(m){byId[m.uuid||m.id]=m;});
          var cursor=root.current_leaf_message_uuid;
          while(cursor && byId[cursor] && !seenNodes[cursor]){seenNodes[cursor]=true;var m=byId[cursor];branch.push(m);cursor=m.parent_message_uuid||m.parent_uuid;}
          if(branch.length)sourceMessages=branch.reverse();
        }
      }
      var messages=sourceMessages.map(function(m){
        var role=m.author?.role||m.sender||m.role;role=role==='human'?'user':role;
        if(!['user','assistant'].includes(role))return null;
        if(platform==='chatgpt' && /reasoning|thought|analysis/.test(m.content?.content_type||m.channel||''))return null;
        var content=platform==='chatgpt'?(m.content?.parts||[]).filter(function(part){return typeof part==='string';}).join('\n'):
          typeof m.text==='string' && m.text.trim()?m.text:(Array.isArray(m.content)?m.content:[]).filter(function(block){return block.type==='text' && typeof block.text==='string';}).map(function(block){return block.text;}).join('\n');
        if(!content.trim())return null;
        var timestamp=typeof m.create_time==='number'?m.create_time:Date.parse(m.created_at)/1000;
        return {...extraMessageFields(m,parents[m.id]),id:String(m.id||m.uuid).slice(0,128),role:role,content:content,...(Number.isFinite(timestamp)?{timestamp:timestamp}:{})};
      }).filter(Boolean);
      var refs=includeFiles?collectFiles(sourceMessages):[];
      var chatRoot=detail.conversation||detail.data||detail;
      var chatMeta=cleanMetadata(Object.assign({},chatRoot.metadata||{},{modelSlug:chatRoot.model_slug||chatRoot.model||chatRoot.metadata?.modelSlug,defaultModelSlug:chatRoot.default_model_slug||chatRoot.metadata?.defaultModelSlug,safeUrls:chatRoot.safe_urls,currentNode:chatRoot.current_node,summary:chatRoot.summary}));
      if(messages.length||refs.length)send({type:'conversation',conversation:{conversationId:item.id,title:item.title,platform:platform,messages:messages,metadata:chatMeta,modelSlug:chatMeta.modelSlug,createdAt:chatRoot.create_time||chatRoot.created_at,updatedAt:chatRoot.update_time||chatRoot.updated_at}});
      var importedFiles=0;
      for(var fi=0;fi<refs.length && !controller.signal.aborted;fi++){
        var file=await queueFile(refs[fi],item.id);if(file.status==='imported')importedFiles++;
      }
      send({type:'item',id:item.id,status:messages.length||importedFiles?'done':'empty'});
      send({type:'progress',completed:++completed,total:selected.length});
      detail=null;
    }}
    await Promise.all(Array.from({length:Math.min(includeFiles?1:3,selected.length)},worker));
    send({type:'complete'});
  }catch(error){send({type:'error',code:timedOut || error.message==='timeout'?'timeout':['sign_in','network','rate_limited','provider_error','invalid_response','conversation_unavailable'].includes(error.message)?error.message:'unavailable'});controller.abort();}
  finally{token=null;clearTimeout(timer);if(window.__onairosNativeImport===controller)delete window.__onairosNativeImport;}})();
})();true;