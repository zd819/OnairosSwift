
(function() {
    try {
        function postDebug(message, details) {
            try {
                window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'DEBUG_LOG',
                    message: '[SEPHORA] ' + message,
                    details: details || null
                }));
            } catch (e) {}
        }

        postDebug('Script started', { version: 'SDK_V6_PURCHASE_DATE_SKU_FIX' });
        
        if (!document.body) {
            window.ReactNativeWebView.postMessage(JSON.stringify({
                type: 'SEPHORA_EXPORT_ERROR',
                message: 'Page not ready'
            }));
            return;
        }

        // ============================================================
        // SEPHORA API CONFIGURATION
        // ============================================================
        
        // Try to pull the API key Sephora itself uses for its own requests
        function extractApiKey() {
            try {
                var w = window;
                if (w.sephoraConfig && w.sephoraConfig.xApiKey) return w.sephoraConfig.xApiKey;
                if (w.SephoraBootstrap && w.SephoraBootstrap.apiKey) return w.SephoraBootstrap.apiKey;
                if (w.__config__ && w.__config__.apiKey) return w.__config__.apiKey;
                if (w.__PRELOADED_STATE__ && w.__PRELOADED_STATE__.config && w.__PRELOADED_STATE__.config.xApiKey) return w.__PRELOADED_STATE__.config.xApiKey;
                // Scan meta tags
                var meta = document.querySelector('meta[name="x-api-key"]') || document.querySelector('meta[name="apiKey"]');
                if (meta) return meta.getAttribute('content');
            } catch (e) {}
            return 'nQc7BFt78yJBvfYDKtle9APd5RrX984i'; // fallback
        }
        
        const SEPHORA_CONFIG = {
            baseUrl: 'https://www.sephora.com',
            apiKey: extractApiKey(),
            
            endpoints: {
                basket: '/api/shopping-cart/basket',
                profileTemplate: '/gapi/users/profiles/{profileId}/current/full',
                lovesTemplate: '/gway/v1/dotcom/users/profiles/{profileId}/lists/skus/all',
                purchasesTemplate: '/api/bi/profiles/{profileId}/purchases',
            },
            
            params: {
                profile: '?skipApis=targetersResult&includeApis=profile,basket,loves,shoppingList,segments',
                loves: '?itemsPerPage=100&currentPage=1&listShortNameLength=20&skipProductDetails=false&includeInactiveSkus=true&fetchAllLovesList=true&sortBy=recently&includeCategories=true',
                purchases: '?sortBy=recently&itemsPerPage=100&groupBy=none&excludeSamples=true&excludeRewards=true',
            }
        };
        
        postDebug('API key source', { hasKey: !!SEPHORA_CONFIG.apiKey });
        
        // ============================================================
        // TOKEN EXTRACTION - From PLATFORM_APIS.md spec
        // ============================================================
        function getSephoraToken() {
            var tokenKeys = ['seph-access-token', 'sephoraAccessToken', 'accessToken'];
            
            // Try localStorage
            for (var i = 0; i < tokenKeys.length; i++) {
                var token = localStorage.getItem(tokenKeys[i]);
                if (token) {
                    try {
                        var parsed = JSON.parse(token);
                        if (parsed && parsed.data) return { token: parsed.data, expiry: parsed.expiry };
                    } catch (e) {
                        return { token: token, expiry: null }; // Not JSON, use as-is
                    }
                }
            }
            
            // Try cookies
            var cookieMatch = document.cookie.match(/seph-access-token=([^;]+)/);
            if (cookieMatch) return { token: cookieMatch[1], expiry: null };
            
            // Try window state
            if (window.__PRELOADED_STATE__ && window.__PRELOADED_STATE__.user) {
                return { token: window.__PRELOADED_STATE__.user.accessToken, expiry: null };
            }
            
            return { token: null, expiry: null };
        }
        
        // ============================================================
        // PROFILE ID EXTRACTION - From PLATFORM_APIS.md spec
        // ============================================================
        function getProfileId(tokenData) {
            // Method 1: From token (JWT payload)
            if (tokenData.token) {
                try {
                    var payload = JSON.parse(atob(tokenData.token.split('.')[1]));
                    if (payload.sub) return payload.sub;
                } catch (e) {}
            }
            
            // Method 2: From localStorage
            var profileId = localStorage.getItem('biAccountId') || 
                            localStorage.getItem('profileId');
            if (profileId) return profileId;
            
            // Method 3: From window state
            if (window.__PRELOADED_STATE__ && window.__PRELOADED_STATE__.user) {
                return window.__PRELOADED_STATE__.user.profileId;
            }
            
            return null;
        }
        
        // ============================================================
        // TOKEN EXPIRY CHECK - From PLATFORM_APIS.md spec
        // ============================================================
        function isTokenExpired(tokenData) {
            if (!tokenData || !tokenData.expiry) return false; // Can't check, assume valid
            
            try {
                var expiry = parseInt(tokenData.expiry, 10);
                var now = Math.floor(Date.now() / 1000);
                return now >= expiry;
            } catch (e) {
                return false;
            }
        }

        console.log('🚀 [SEPHORA] Starting extraction with real APIs...');

        (async () => {
            try {
                // STEP 1: Get authentication data
                window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'SEPHORA_EXPORT_PROGRESS',
                    stage: 'fetching_auth',
                    progress: 2,
                    message: 'Getting authentication...'
                }));

                console.log('[SEPHORA] Getting auth data...');
                const tokenData = getSephoraToken();
                const profileId = getProfileId(tokenData);
                
                console.log('[SEPHORA] Auth:', {
                    hasToken: !!tokenData.token,
                    tokenLength: tokenData.token ? tokenData.token.length : 0,
                    hasExpiry: !!tokenData.expiry,
                    isExpired: isTokenExpired(tokenData),
                    profileId: profileId
                });
                postDebug('Auth state', {
                    hasToken: !!tokenData.token,
                    tokenLength: tokenData.token ? tokenData.token.length : 0,
                    hasExpiry: !!tokenData.expiry,
                    isExpired: isTokenExpired(tokenData),
                    profileId: profileId
                });

                if (!tokenData.token) {
                    throw new Error('Not authenticated - please log in to Sephora');
                }
                
                if (isTokenExpired(tokenData)) {
                    console.warn('[SEPHORA] Token may be expired');
                }

                // Use headers captured from Sephora's own page requests.
                // Sephora APIs are cookie-authed — DON'T add a Bearer token unless Sephora
                // itself sent one, as it can cause 401s on endpoints that don't expect it.
                var capturedCapture = window.__onairosCapture || {};
                var capturedHeaders = capturedCapture.headers || null;
                var capturedData = capturedCapture.data || {};
                var resolvedApiKey = (capturedHeaders && capturedHeaders['x-api-key']) || SEPHORA_CONFIG.apiKey;
                var headers = {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'x-api-key': resolvedApiKey,
                };
                if (tokenData && tokenData.token) {
                    // Several Sephora endpoints are gated by this explicit header.
                    headers['seph-access-token'] = tokenData.token;
                    headers['x-seph-access-token'] = tokenData.token;
                }
                if (capturedHeaders && capturedHeaders['Authorization']) {
                    headers['Authorization'] = capturedHeaders['Authorization'];
                } else if (tokenData && tokenData.token) {
                    headers['Authorization'] = 'Bearer ' + tokenData.token;
                }
                postDebug('Headers', {
                    apiKeySrc: (capturedHeaders && capturedHeaders['x-api-key']) ? 'captured' : 'fallback',
                    hasApiKey: !!resolvedApiKey,
                    hasAuth: !!(capturedHeaders && capturedHeaders['Authorization']),
                    capturedDataKeys: Object.keys(capturedData).join(',') || 'none',
                });

                // STEP 2: Fetch basket (doesn't require profileId)
                window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'SEPHORA_EXPORT_PROGRESS',
                    stage: 'fetching_basket',
                    progress: 10,
                    message: 'Fetching shopping basket...'
                }));

                let basket = { items: [], subtotal: 0 };
                let extractedProfileId = profileId;
                console.log('[SEPHORA] Fetching basket from:', SEPHORA_CONFIG.endpoints.basket);
                postDebug('Fetching basket', {
                    url: SEPHORA_CONFIG.baseUrl + SEPHORA_CONFIG.endpoints.basket
                });
                
                function parseBasketData(basketData) {
                    var rawBasket = basketData.basket || basketData.BasketListModel || basketData;
                    var rawItems = rawBasket.items || rawBasket.products || basketData.items || basketData.products || [];
                    postDebug('Basket keys', { keys: Object.keys(basketData).join(','), count: rawItems.length });
                    basket = {
                        items: rawItems.map(function(item) {
                            return {
                                skuId: item.skuId || item.sku_id || item.id,
                                productId: item.productId || item.product_id,
                                name: item.displayName || item.name || item.productName,
                                brand: item.brand || item.brandName,
                                price: item.price || item.currentPrice || item.listPrice,
                                quantity: item.quantity || 1,
                                size: item.size || item.variationValue,
                                imageUrl: item.image || item.heroImage || item.thumbnail,
                            };
                        }),
                        subtotal: rawBasket.subtotal || rawBasket.total || rawBasket.orderTotal || basketData.subtotal || 0,
                        biPoints: rawBasket.biPoints || rawBasket.beautyInsiderPoints || 0,
                    };
                    if (!extractedProfileId && (rawBasket.profileId || basketData.profileId)) {
                        extractedProfileId = rawBasket.profileId || basketData.profileId;
                    }
                    postDebug('Basket parsed', { itemCount: basket.items.length, subtotal: basket.subtotal });
                }

                function hasMeaningfulBasketCapture(data) {
                    if (!data || typeof data !== 'object') return false;
                    var rawBasket = data.basket || data.BasketListModel || data;
                    var rawItems = rawBasket.items || rawBasket.products || data.items || data.products || [];
                    return Array.isArray(rawItems) && rawItems.length > 0;
                }

                if (hasMeaningfulBasketCapture(capturedData.basket)) {
                    postDebug('Basket from meaningful capture', {});
                    parseBasketData(capturedData.basket);
                } else {
                    if (capturedData.basket) {
                        postDebug('Basket capture unusable; fetching live basket', {});
                    }
                    try {
                        const basketResponse = await fetch(SEPHORA_CONFIG.baseUrl + SEPHORA_CONFIG.endpoints.basket, {
                            method: 'GET', credentials: 'include', headers: headers
                        });
                        postDebug('Basket HTTP status', { status: basketResponse.status, ok: basketResponse.ok });
                        const basketText = await basketResponse.text();
                        postDebug('Basket body received', { hasBody: basketText.length > 0 });
                        if (basketResponse.ok) {
                            var basketData = {};
                            try { basketData = JSON.parse(basketText); } catch (e) { postDebug('Basket parse error', { err: e.message }); }
                            parseBasketData(basketData);
                        }
                    } catch (basketErr) {
                        postDebug('Basket fetch error', { message: basketErr.message });
                    }
                }

                // STEP 3: Fetch Loves/Favorites (requires profileId)
                window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'SEPHORA_EXPORT_PROGRESS',
                    stage: 'fetching_loves',
                    progress: 30,
                    message: 'Fetching loved products...'
                }));

                let loves = [];
                if (extractedProfileId) {
                    const lovesUrl = SEPHORA_CONFIG.baseUrl + 
                        SEPHORA_CONFIG.endpoints.lovesTemplate.replace('{profileId}', extractedProfileId) +
                        SEPHORA_CONFIG.params.loves;
                    
                    console.log('[SEPHORA] Fetching loves from:', lovesUrl);
                    postDebug('Fetching loves', { url: lovesUrl });
                    
                    function parseLovesData(lovesData) {
                        var rawLoves = lovesData.skus || lovesData.items || lovesData.products ||
                                        lovesData.listItems || (lovesData.skuList && lovesData.skuList.items) ||
                                        (Array.isArray(lovesData) ? lovesData : []);
                        if (!Array.isArray(rawLoves) && rawLoves) {
                            rawLoves = rawLoves.items || rawLoves.products || rawLoves.skus || [];
                        }
                        if (!Array.isArray(rawLoves)) {
                            rawLoves = [];
                        }
                        postDebug('Loves keys', { keys: Object.keys(lovesData).join(','), count: rawLoves.length });
                        loves = rawLoves.map(function(item) {
                            var nestedSku = item && item.sku && typeof item.sku === 'object' ? item.sku : {};
                            var nestedProduct = item && item.product && typeof item.product === 'object' ? item.product : {};
                            return {
                                skuId: item.skuId || item.sku_id || nestedSku.skuId || nestedSku.id || item.id,
                                productId: item.productId || item.product_id || nestedSku.productId || nestedProduct.productId,
                                name: item.displayName || item.name || item.productName || nestedSku.displayName || nestedSku.productName || nestedProduct.displayName || nestedProduct.name,
                                brand: item.brand || item.brandName || nestedSku.brandName || nestedProduct.brandName,
                                category: item.category || item.primaryCategory || item.breadcrumb,
                                price: item.price || item.listPrice || item.currentPrice || nestedSku.listPrice || nestedSku.currentPrice,
                                salePrice: item.salePrice || item.discountedPrice,
                                rating: item.rating || item.averageRating || item.starRating,
                                reviewCount: item.reviewCount || item.numberOfReviews,
                                isInStock: item.isInStock !== false && item.inStock !== false,
                                isOnSale: item.isOnSale || item.onSale || !!item.salePrice,
                                imageUrl: item.image || item.heroImage || item.thumbnail || nestedSku.image,
                                addedAt: item.addedAt || item.dateAdded || item.createdAt,
                            };
                        });
                        postDebug('Loves parsed', { itemCount: loves.length });
                    }

                    function hasMeaningfulLovesCapture(data) {
                        if (!data || typeof data !== 'object') return false;
                        var rawLoves = data.skus || data.items || data.products ||
                                       data.listItems || (data.skuList && data.skuList.items) ||
                                       (Array.isArray(data) ? data : []);
                        if (!Array.isArray(rawLoves) && rawLoves) {
                            rawLoves = rawLoves.items || rawLoves.products || rawLoves.skus || [];
                        }
                        return Array.isArray(rawLoves) && rawLoves.length > 0;
                    }

                    if (hasMeaningfulLovesCapture(capturedData.loves)) {
                        postDebug('Loves from meaningful capture', {});
                        parseLovesData(capturedData.loves);
                    } else {
                        if (capturedData.loves) {
                            postDebug('Loves capture unusable; fetching live loves', {});
                        }
                        try {
                            const lovesResponse = await fetch(lovesUrl, {
                                method: 'GET', credentials: 'include', headers: headers
                            });
                            postDebug('Loves HTTP status', { status: lovesResponse.status, ok: lovesResponse.ok });
                            const lovesText = await lovesResponse.text();
                            postDebug('Loves body received', { hasBody: lovesText.length > 0 });
                            if (lovesResponse.ok) {
                                var lovesData = {};
                                try { lovesData = JSON.parse(lovesText); } catch (e) { postDebug('Loves parse error', { err: e.message }); }
                                parseLovesData(lovesData);
                            }
                        } catch (lovesErr) {
                            postDebug('Loves fetch error', { message: lovesErr.message });
                        }
                    }
                } else {
                    console.warn('[SEPHORA] Skipping loves - no profileId');
                    postDebug('Skipping loves', { reason: 'no profileId' });
                }

                // STEP 4: Fetch Purchase History (requires profileId)
                window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'SEPHORA_EXPORT_PROGRESS',
                    stage: 'fetching_purchases',
                    progress: 55,
                    message: 'Fetching purchase history...'
                }));

                let purchases = [];

                function parsePurchasesData(purchasesData) {
                    var rawPurchases = purchasesData.purchases || purchasesData.orders ||
                                         purchasesData.purchaseHistoryList || purchasesData.items ||
                                         purchasesData.purchasedItems ||
                                         (purchasesData.purchaseHistory && purchasesData.purchaseHistory.orders) ||
                                         (purchasesData.purchaseHistory && purchasesData.purchaseHistory.purchasedItems) ||
                                         (Array.isArray(purchasesData) ? purchasesData : []);
                    if (!Array.isArray(rawPurchases) && rawPurchases) {
                        rawPurchases = rawPurchases.orders || rawPurchases.items || rawPurchases.purchasedItems || [];
                    }
                    if (!Array.isArray(rawPurchases)) {
                        rawPurchases = [];
                    }
                    postDebug('Purchases keys', { keys: Object.keys(purchasesData).join(','), count: rawPurchases.length });
                    if (rawPurchases.length > 0 && rawPurchases[0] && typeof rawPurchases[0] === 'object') {
                        postDebug('Purchases first entry keys', { keys: Object.keys(rawPurchases[0]).join(',') });
                    }

                    function normalizePurchaseItem(rawItem, index) {
                        var source = rawItem || {};
                        var nestedProduct = source.product || source.sku || source.skuItem || source.item || source.productData || {};
                        var sourceSku = source.sku;
                        var sourceSkuId = (sourceSku && typeof sourceSku === 'object') ? sourceSku.skuId : sourceSku;

                        var skuId = source.skuId || source.sku_id || sourceSkuId || nestedProduct.skuId || nestedProduct.sku_id || nestedProduct.id || source.id || null;
                        var productId = source.productId || source.product_id || nestedProduct.productId || nestedProduct.product_id || nestedProduct.id || null;
                        var name = source.displayName || source.name || source.productName || nestedProduct.displayName || nestedProduct.name || nestedProduct.productName || null;
                        var brand = source.brand || source.brandName || nestedProduct.brand || nestedProduct.brandName || null;
                        var price = source.price || source.purchasePrice || source.salePrice ||
                                    source.listPrice || nestedProduct.price || nestedProduct.purchasePrice || nestedProduct.listPrice || null;
                        var quantity = source.quantity || nestedProduct.quantity || 1;

                        if (!skuId && productId) {
                            skuId = 'PRODUCT_' + productId;
                        }
                        if (!skuId && name) {
                            skuId = 'ITEM_' + index;
                        }
                        if (!name) {
                            name = source.title || nestedProduct.title || 'Unknown product';
                        }

                        return {
                            skuId: skuId,
                            productId: productId || undefined,
                            name: name,
                            brand: brand || undefined,
                            price: price || undefined,
                            quantity: quantity,
                        };
                    }

                    purchases = rawPurchases.map(function(orderLike, index) {
                        var nestedItems = orderLike.items || orderLike.products || orderLike.skus || [];
                        var hasNestedItems = Array.isArray(nestedItems) && nestedItems.length > 0;

                        var orderItems = hasNestedItems
                            ? nestedItems.map(function(item, nestedIndex) {
                                return normalizePurchaseItem(item, nestedIndex);
                            })
                            : [normalizePurchaseItem(orderLike, index)];

                        var fallbackOrderId = orderLike.orderId || orderLike.id || orderLike.orderNumber || ('ORDER_' + index);
                        var transactionDate = orderLike.transactionDate ||
                                              orderLike.lastPurchasedDate ||
                                              (orderLike.sku && orderLike.sku.transactionDate) ||
                                              null;
                        var normalizedOrderDate = null;
                        if (typeof transactionDate === 'number') {
                            normalizedOrderDate = new Date(transactionDate).toISOString();
                        } else if (typeof transactionDate === 'string' && transactionDate) {
                            // If it's an epoch-in-string, normalize; otherwise pass through.
                            var asNumber = Number(transactionDate);
                            normalizedOrderDate = Number.isNaN(asNumber)
                                ? transactionDate
                                : new Date(asNumber).toISOString();
                        }

                        var fallbackOrderDate = orderLike.orderDate || orderLike.date || orderLike.purchaseDate ||
                                                normalizedOrderDate || orderLike.createdAt || null;

                        return {
                            orderId: fallbackOrderId,
                            orderDate: fallbackOrderDate,
                            total: orderLike.total || orderLike.orderTotal || null,
                            channel: orderLike.channel || orderLike.purchaseChannel || 'online',
                            items: orderItems.filter(function(item) { return item && item.skuId && item.name; }),
                        };
                    }).filter(function(order) {
                        return !!order.orderId && order.items.length > 0;
                    });
                    postDebug('Purchases parsed', { orderCount: purchases.length });

                    var declaredCount = purchasesData.purchasedItemsCount || purchasesData.totalPurchasedItems || 0;
                    if (declaredCount > 0 && purchases.length === 0) {
                        postDebug('Purchases parse mismatch', {
                            declaredCount: declaredCount,
                            parsedCount: purchases.length
                        });
                    }
                }

                function hasMeaningfulPurchasesCapture(data) {
                    if (!data || typeof data !== 'object') return false;
                    var rawPurchases = data.purchases || data.orders ||
                                       data.purchaseHistoryList || data.items ||
                                       data.purchasedItems ||
                                       (data.purchaseHistory && data.purchaseHistory.orders) ||
                                       (data.purchaseHistory && data.purchaseHistory.purchasedItems) ||
                                       (Array.isArray(data) ? data : []);
                    if (!Array.isArray(rawPurchases) && rawPurchases) {
                        rawPurchases = rawPurchases.orders || rawPurchases.items || rawPurchases.purchasedItems || [];
                    }
                    return Array.isArray(rawPurchases) && rawPurchases.length > 0;
                }

                if (hasMeaningfulPurchasesCapture(capturedData.purchases)) {
                    postDebug('Purchases from meaningful capture', {});
                    parsePurchasesData(capturedData.purchases);
                } else if (extractedProfileId) {
                    if (capturedData.purchases) {
                        postDebug('Purchases capture unusable; fetching live purchases', {});
                    }
                    const purchasesUrl = SEPHORA_CONFIG.baseUrl + 
                        SEPHORA_CONFIG.endpoints.purchasesTemplate.replace('{profileId}', extractedProfileId) +
                        SEPHORA_CONFIG.params.purchases;
                    
                    postDebug('Fetching purchases', { url: purchasesUrl });
                    
                    try {
                        const purchasesResponse = await fetch(purchasesUrl, {
                            method: 'GET',
                            credentials: 'include',
                            headers: headers
                        });
                        
                        postDebug('Purchases HTTP status', { status: purchasesResponse.status, ok: purchasesResponse.ok });
                        
                        const purchasesText = await purchasesResponse.text();
                        postDebug('Purchases body received', { hasBody: purchasesText.length > 0 });
                        
                        if (purchasesResponse.ok) {
                            var purchasesData = {};
                            try { purchasesData = JSON.parse(purchasesText); } catch (e) { postDebug('Purchases parse error', { err: e.message }); }
                            parsePurchasesData(purchasesData);
                        } else if (purchasesResponse.status === 401 || purchasesResponse.status === 403) {
                            postDebug('Purchases auth failed, trying alt endpoint', { status: purchasesResponse.status });
                            try {
                                var altUrl = SEPHORA_CONFIG.baseUrl + '/api/users/profiles/' + extractedProfileId + '/orders?pageSize=50&currentPage=1';
                                const altResp = await fetch(altUrl, { method: 'GET', credentials: 'include', headers: headers });
                                postDebug('Purchases alt status', { status: altResp.status });
                                if (altResp.ok) {
                                    var altData = {};
                                    try { altData = JSON.parse(await altResp.text()); } catch(e) {}
                                    parsePurchasesData(altData);
                                }
                            } catch(altErr) { postDebug('Purchases alt error', { message: altErr.message }); }
                        }
                    } catch (purchasesErr) {
                        postDebug('Purchases fetch error', { message: purchasesErr.message });
                    }
                } else {
                    postDebug('Skipping purchases', { reason: 'no profileId' });
                }

                // STEP 5: Fetch User Profile (requires profileId)
                window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'SEPHORA_EXPORT_PROGRESS',
                    stage: 'fetching_profile',
                    progress: 75,
                    message: 'Fetching beauty profile...'
                }));

                let profile = null;

                function parseProfileData(profileData) {
                    var pd = profileData.userProfile || profileData.profile || profileData;
                    postDebug('Profile top-level keys', { keys: Object.keys(profileData).join(',') });
                    profile = {
                        profileId: pd.profileId || profileData.profileId || extractedProfileId,
                        firstName: pd.firstName,
                        lastName: pd.lastName,
                        email: pd.email,
                        vibStatus: pd.vibStatus || pd.biTier || pd.tier,
                        beautyInsider: {
                            points: pd.biPoints || pd.points || pd.beautyInsiderPoints,
                            segment: pd.segment || pd.biSegment,
                            spending: pd.spending || pd.yearlySpend,
                        },
                        preferences: {
                            skinConcerns: pd.skinConcerns || pd.skinType || [],
                            hairConcerns: pd.hairConcerns || pd.hairType || [],
                            makeupPreferences: pd.makeupPreferences || [],
                        },
                        preferredStore: pd.preferredStore || pd.homeStore,
                    };
                    postDebug('Profile parsed', {
                        profileId: profile.profileId,
                        firstName: profile.firstName,
                        vibStatus: profile.vibStatus,
                    });
                }

                function hasMeaningfulProfileCapture(data) {
                    if (!data || typeof data !== 'object') return false;
                    var pd = data.userProfile || data.profile || data;
                    return !!(pd && (pd.profileId || pd.firstName || pd.lastName || pd.email || pd.vibStatus || pd.biTier));
                }

                if (hasMeaningfulProfileCapture(capturedData.profile)) {
                    postDebug('Profile from capture', {});
                    parseProfileData(capturedData.profile);
                } else if (extractedProfileId) {
                    if (capturedData.profile) {
                        postDebug('Profile capture unusable; fetching live profile', {});
                    }
                    const profileUrl = SEPHORA_CONFIG.baseUrl + 
                        SEPHORA_CONFIG.endpoints.profileTemplate.replace('{profileId}', extractedProfileId) +
                        SEPHORA_CONFIG.params.profile;
                    
                    postDebug('Fetching profile', { url: profileUrl });
                    
                    try {
                        const profileResponse = await fetch(profileUrl, {
                            method: 'GET',
                            credentials: 'include',
                            headers: headers
                        });
                        
                        postDebug('Profile HTTP status', { status: profileResponse.status, ok: profileResponse.ok });
                        
                        const profileText = await profileResponse.text();
                        postDebug('Profile body received', { hasBody: profileText.length > 0 });
                        
                        if (profileResponse.ok) {
                            var profileData = {};
                            try { profileData = JSON.parse(profileText); } catch (e) { postDebug('Profile parse error', { e: e.message }); }
                            parseProfileData(profileData);
                        }
                    } catch (profileError) {
                        postDebug('Profile fetch error', { message: profileError.message });
                    }
                }

                // STEP 6: Send results
                window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'SEPHORA_EXPORT_PROGRESS',
                    stage: 'complete',
                    progress: 95,
                    message: 'Finalizing...'
                }));

                console.log('✅ [SEPHORA] Extraction complete:', {
                    basket: basket.items.length,
                    loves: loves.length,
                    purchases: purchases.length,
                    hasProfile: !!profile
                });
                postDebug('Extraction complete', {
                    basketItems: basket.items.length,
                    loves: loves.length,
                    purchases: purchases.length,
                    hasProfile: !!profile
                });

                var totalPurchasedItems = purchases.reduce(function(sum, order) {
                    return sum + ((order.items && order.items.length) || 0);
                }, 0);
                var vibStatus = (profile && profile.vibStatus) || 'unknown';
                var biPoints = (profile && profile.beautyInsider && profile.beautyInsider.points) || basket.biPoints || 0;

                if (basket.items.length === 0 && loves.length === 0 && purchases.length === 0 && !profile) {
                    postDebug('Extraction empty after live fetch attempts', {
                        profileId: extractedProfileId,
                        hasToken: !!(tokenData && tokenData.token),
                    });
                    window.ReactNativeWebView.postMessage(JSON.stringify({
                        type: 'SEPHORA_EXPORT_ERROR',
                        status: 'error',
                        message: 'No usable Sephora data found (basket/loves/purchases/profile were all empty).',
                        success: false
                    }));
                    return;
                }

                window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'SEPHORA_EXPORT_COMPLETE',
                    status: 'success',
                    data: {
                        basket: basket,
                        loves: loves,
                        purchases: purchases,
                        profile: profile,
                        summary: {
                            totalBasketItems: basket.items.length,
                            basketSubtotal: basket.subtotal,
                            totalLovedProducts: loves.length,
                            totalOrders: purchases.length,
                            totalPurchasedItems: totalPurchasedItems,
                            vibStatus: vibStatus,
                            biPoints: biPoints,
                        },
                        tokenExpiry: {
                            expiry: tokenData.expiry,
                            isExpired: isTokenExpired(tokenData),
                        },
                        profileId: extractedProfileId,
                    },
                    success: true
                }));

            } catch (error) {
                console.error('❌ [SEPHORA] Export failed:', error.message);
                postDebug('Export failed', { message: error.message });
                window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'SEPHORA_EXPORT_ERROR',
                    status: 'error',
                    message: 'Fetch failed: ' + error.message,
                    success: false
                }));
            }
        })();

    } catch (error) {
        console.error('❌ [SEPHORA] Init error:', error.message);
        try {
            window.ReactNativeWebView.postMessage(JSON.stringify({
                type: 'DEBUG_LOG',
                message: '[SEPHORA] Init error',
                details: { message: error.message }
            }));
        } catch (e) {}
        window.ReactNativeWebView.postMessage(JSON.stringify({
            type: 'SEPHORA_EXPORT_ERROR',
            status: 'error',
            message: 'Script error: ' + error.message,
            success: false
        }));
    }
})();
true;
