(function(){
    if(window.top!==window.self) return;
    if(window.__onairosSessionObserver){window.__onairosSessionObserver();return;}
    var stopped=false, authenticated=false, ready=null, timer, polling=false;
    var loginEntry=false;
    var openingLogin=loginEntry, loginAttempted=false, loginController;
    function send(type){if(!stopped)window.webkit.messageHandlers.onairosImport.postMessage(JSON.stringify({channel:'onairos-native-session',channelId:"__CHANNEL__",type:type}));}
    function checkPage(){
      var body=document.body;
      // Auth redirects can finish loading before their SPA has painted a form.
      var visible=!openingLogin && !!body && Array.from(body.querySelectorAll('input:not([type="hidden"]),button,h1,h2,[role="button"],iframe')).some(function(el){
        var rect=el.getBoundingClientRect();return rect.width>0 && rect.height>0 && (!el.checkVisibility || el.checkVisibility({opacityProperty:true,visibilityProperty:true}));
      });
      if(visible!==ready){ready=visible;send(visible?'page_ready':'page_pending');}
    }
    async function openLogin(){
      if(!loginEntry || loginAttempted || stopped)return;
      loginAttempted=true;loginController=new AbortController();
      var redirected=false, timeout=setTimeout(function(){loginController.abort();},15000);
      try{
        // Start the provider's normal CSRF-protected OAuth flow in this same
        // private WebView. Its intermediary email form drops the email hint.
        var csrfResponse=await fetch('/api/auth/csrf',{credentials:'include',signal:loginController.signal,headers:{Accept:'application/json'}});
        if(!csrfResponse.ok)throw new Error('login_unavailable');
        var csrf=await csrfResponse.json();
        if(typeof csrf.csrfToken!=='string' || !csrf.csrfToken)throw new Error('login_unavailable');
        var response=await fetch('/api/auth/signin/openai',{method:'POST',credentials:'include',signal:loginController.signal,
          headers:{'Content-Type':'application/x-www-form-urlencoded',Accept:'application/json'},
          body:'csrfToken='+encodeURIComponent(csrf.csrfToken)+'&callbackUrl='+encodeURIComponent('https://chatgpt.com/')+'&json=true'});
        csrf=null;
        if(!response.ok)throw new Error('login_unavailable');
        var result=await response.json(), target=new URL(result.url);
        if(target.origin!=='https://auth.openai.com' || target.username || target.password)throw new Error('login_unavailable');
        if(!stopped && !loginController.signal.aborted){redirected=true;location.replace(target.href);}
      }catch(_){}finally{
        clearTimeout(timeout);openingLogin=redirected;checkPage();
      }
    }
    async function checkSession(){
      if(stopped || authenticated || polling || location.origin!=="https://claude.ai")return;
      polling=true;
      var controller=new AbortController(), timeout=setTimeout(function(){controller.abort();},4000);
      try{
        var response=await fetch("/api/organizations",{credentials:'include',redirect:'error',signal:controller.signal,headers:{Accept:'application/json'}});
        if(response.ok){var session=await response.json();authenticated=(Array.isArray(session)?session:session.organizations||[]).some(function(org){return typeof (org.uuid||org.id)==='string';});session=null;if(authenticated){if(location.pathname==='/login'){location.replace("https://claude.ai/new");return;}send('authenticated');}}
      }catch(_){}finally{polling=false;clearTimeout(timeout);}
      if(!authenticated)void openLogin();
    }
    function tick(){if(stopped)return;checkPage();void checkSession();timer=setTimeout(tick,1500);}
    window.__onairosSessionObserver=function(){ready=null;checkPage();void checkSession();};
    var observer=new MutationObserver(checkPage);
    function observe(){if(document.documentElement)observer.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','hidden']});}
    observe();document.addEventListener('DOMContentLoaded',observe,{once:true});
    window.addEventListener('pagehide',function(){stopped=true;clearTimeout(timer);if(loginController)loginController.abort();observer.disconnect();},{once:true});
    tick();
  })();true;